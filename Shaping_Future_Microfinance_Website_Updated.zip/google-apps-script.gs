/**
 * Shaping Future Microfinance Pvt. Ltd. website enquiry receiver.
 * 1) Create a Google Sheet, copy its ID from the URL.
 * 2) Create a standalone Apps Script project and paste this file.
 * 3) Set SHEET_ID below. Run setupSheet once and authorize.
 * 4) Deploy > New deployment > Web app. Execute as: Me.
 *    Access: choose the broadest access your Google account permits and your company approves.
 *    Public anonymous access can attract spam; monitor submissions and rotate the deployment if abused.
 * 5) Copy the deployment URL ending /exec into js/script.js.
 */
const SHEET_ID = 'PASTE_GOOGLE_SHEET_ID_HERE';
const NOTIFY_EMAIL = 'shapingfuture22@gmail.com';
const TAB_NAME = 'Website Enquiries';
function setupSheet() {
  if (SHEET_ID === 'PASTE_GOOGLE_SHEET_ID_HERE') throw new Error('Set SHEET_ID first.');
  const ss = SpreadsheetApp.openById(SHEET_ID);
  let sheet = ss.getSheetByName(TAB_NAME);
  if (!sheet) sheet = ss.insertSheet(TAB_NAME);
  if (sheet.getLastRow() === 0) sheet.appendRow(['Timestamp','Name','Mobile','Email','Enquiry Type','Message','Status']);
  sheet.setFrozenRows(1);
}
function doPost(e) {
  try {
    if (SHEET_ID === 'PASTE_GOOGLE_SHEET_ID_HERE') throw new Error('Website form is not configured.');
    const raw = e && e.postData && e.postData.contents ? e.postData.contents : '{}';
    const data = JSON.parse(raw);
    const name = clean(data.name, 100);
    const mobile = clean(data.mobile, 20);
    const email = clean(data.email, 150);
    const enquiry = clean(data.enquiry, 100);
    const message = clean(data.message, 3000);
    if (!name || !email || !message) throw new Error('Name, email and message are required.');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('Invalid email address.');
    const ss = SpreadsheetApp.openById(SHEET_ID);
    let sheet = ss.getSheetByName(TAB_NAME);
    if (!sheet) { sheet = ss.insertSheet(TAB_NAME); sheet.appendRow(['Timestamp','Name','Mobile','Email','Enquiry Type','Message','Status']); }
    sheet.appendRow([new Date(), name, mobile, email, enquiry, message, 'New']);
    MailApp.sendEmail({to: NOTIFY_EMAIL, subject: 'Website Enquiry: ' + enquiry, body: 'A new website enquiry was received.\n\nName: ' + name + '\nMobile: ' + mobile + '\nEmail: ' + email + '\nType: ' + enquiry + '\n\nMessage:\n' + message});
    return ContentService.createTextOutput(JSON.stringify({ok:true})).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    console.error(err);
    return ContentService.createTextOutput(JSON.stringify({ok:false, error:'Submission could not be processed.'})).setMimeType(ContentService.MimeType.JSON);
  }
}
function clean(value, max) { return String(value || '').replace(/[<>]/g, '').trim().slice(0, max); }
