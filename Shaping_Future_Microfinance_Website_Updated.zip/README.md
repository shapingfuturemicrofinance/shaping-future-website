# Shaping Future Microfinance Pvt. Ltd. — Website Update

This is an updated bilingual (English/Hindi) static website for GitHub Pages.

## Files
- `index.html` — bilingual corporate site, SHG/loan information, RD/FD compliance note, careers and contact form
- `css/style.css` — responsive styling
- `js/script.js` — language toggle and contact form submission configuration
- `google-apps-script.gs` — Google Sheets + email notification backend for enquiries
- `portal.html` — safe employee portal placeholder (login intentionally disabled until secure auth is configured)
- `privacy.html`, `disclaimer.html` — initial website notices; review with your compliance adviser

## 1. Upload to existing GitHub repository
1. Download/extract this ZIP on your computer.
2. Open your existing GitHub website repository.
3. Upload the files and folders from this ZIP to the same folder that currently contains `index.html` (replace existing files when asked).
4. Commit changes to your publishing branch (often `main`).
5. In repository Settings → Pages, verify the existing publishing source. GitHub Pages can take several minutes to publish changes.

## 2. Connect contact form to Google Sheet + email
1. Create a new Google Sheet. Copy the ID from its URL: `https://docs.google.com/spreadsheets/d/SHEET_ID/edit`.
2. Open `script.google.com` → New project. Paste the contents of `google-apps-script.gs`.
3. Replace `PASTE_GOOGLE_SHEET_ID_HERE` with your Sheet ID. Save.
4. Select `setupSheet` and Run once; authorize Google access.
5. Deploy → New deployment → Web app. Execute as: Me. Set access based on your organization's policy and what your Google account permits. Public access means anyone can attempt to submit; monitor spam and do not collect sensitive information.
6. Copy the deployed URL ending in `/exec`.
7. Open `js/script.js` and replace `PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_EXEC_URL_HERE` with that URL. Commit this change to GitHub.
8. Submit a test enquiry. Check both the Google Sheet and `shapingfuture22@gmail.com` inbox/spam.

The browser uses `no-cors` for Apps Script submission, so it cannot inspect the server's response. Verify the Sheet and email before treating the integration as live.

## 3. Employee login / admin panel
The portal currently does **not** authenticate anyone and does not expose a fake login that appears secure. GitHub Pages is static hosting; it cannot safely protect employee records by itself. Before enabling staff access, configure a real identity provider/backend (for example Firebase Authentication with properly secured database rules, or a managed backend), create employee accounts, enforce role-based access and test permissions. Never put passwords, API secrets or admin keys in public website files.

## 4. Financial-services content
Before publishing any claims about RD/FD deposits, interest rates, loan products, licensing, guarantees, or approvals, have the company confirm the relevant legal authorization and official product terms. The current website deliberately does not claim RD/FD products are available.

## 5. Before going live
- Confirm company legal details and contact email.
- Review Privacy Notice and Disclaimer for your actual data practices and applicable laws.
- Do not collect Aadhaar, PAN scans, bank credentials, OTPs or sensitive KYC documents through this general enquiry form.
- Use a separate, properly secured process for any regulated customer/member records.
