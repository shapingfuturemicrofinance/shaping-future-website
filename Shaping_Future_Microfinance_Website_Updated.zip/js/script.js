// Website settings. After deploying google-apps-script.gs as a Web App, paste its /exec URL below.
const GOOGLE_APPS_SCRIPT_URL = "PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_EXEC_URL_HERE";
const menuBtn = document.getElementById('menuBtn');
const nav = document.getElementById('mainNav');
if (menuBtn && nav) {
  menuBtn.addEventListener('click', () => nav.classList.toggle('open'));
  nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));
}
let currentLanguage = 'en';
const langToggle = document.getElementById('langToggle');
function setLanguage(lang) {
  currentLanguage = lang;
  document.documentElement.lang = lang;
  document.querySelectorAll('[data-en][data-hi]').forEach(el => {
    const value = el.getAttribute(`data-${lang}`);
    if (value !== null) {
      if (value.includes('<br>') || value.includes('<span>')) el.innerHTML = value;
      else el.textContent = value;
    }
  });
  if (langToggle) langToggle.textContent = lang === 'en' ? 'हिंदी' : 'English';
}
if (langToggle) langToggle.addEventListener('click', () => setLanguage(currentLanguage === 'en' ? 'hi' : 'en'));
const contactForm = document.getElementById('contactForm');
if (contactForm) contactForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const status = document.getElementById('formStatus');
  const submit = contactForm.querySelector('button[type="submit"]');
  const tr = (en, hi) => currentLanguage === 'hi' ? hi : en;
  if (contactForm.elements.website.value) return;
  if (!GOOGLE_APPS_SCRIPT_URL.startsWith('https://script.google.com/macros/s/') || !GOOGLE_APPS_SCRIPT_URL.endsWith('/exec')) {
    status.textContent = tr('Setup needed: deploy google-apps-script.gs and paste its Web App /exec URL into js/script.js.', 'सेटअप आवश्यक: google-apps-script.gs को Web App के रूप में डिप्लॉय करें और उसका /exec URL js/script.js में डालें।');
    status.classList.add('error'); return;
  }
  const data = Object.fromEntries(new FormData(contactForm).entries());
  delete data.website;
  submit.disabled = true;
  status.textContent = tr('Sending your enquiry…', 'आपकी पूछताछ भेजी जा रही है…');
  try {
    // no-cors is used for Apps Script browser submissions; server-side validation and Sheet/email logs are authoritative.
    await fetch(GOOGLE_APPS_SCRIPT_URL, { method: 'POST', mode: 'no-cors', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(data) });
    status.textContent = tr('Your enquiry was submitted. If you do not receive a response, please email shapingfuture22@gmail.com.', 'आपकी पूछताछ भेज दी गई है। जवाब न मिलने पर shapingfuture22@gmail.com पर ईमेल करें।');
    status.classList.remove('error'); contactForm.reset();
  } catch (err) {
    status.textContent = tr('Could not submit. Please email shapingfuture22@gmail.com.', 'फॉर्म सबमिट नहीं हो पाया। कृपया shapingfuture22@gmail.com पर ईमेल करें।');
    status.classList.add('error');
  } finally { submit.disabled = false; }
});
