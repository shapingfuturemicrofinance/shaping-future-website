# Shaping Future Microfinance Pvt. Ltd. — GitHub Website

A responsive static corporate website for Shaping Future Microfinance Pvt. Ltd.

## Included

- Professional responsive corporate homepage
- About, Services, Financial Inclusion and How It Works sections
- Customer/Member information
- Technology section
- Careers and Contact section
- Employee Login entry point
- GM Login UI
- Staff Login UI
- Role-based dashboard UI mockup
- Attendance / field report / approval modules as backend-ready UI
- User-provided company logo
- Contact email: shapingfuture22@gmail.com
- CIN: U65990DL2022PTC400053

## Important

The GM/Staff login included here is a **front-end demonstration UI**. It is not a production authentication system.

Before using the portal with real employees or customer data, connect it to a secure backend/authentication provider and database. Do not store passwords in frontend code or expose confidential information.

## GitHub Pages

1. Upload the complete project folder to a GitHub repository.
2. Keep `index.html` in the repository root.
3. Go to **Settings → Pages**.
4. Select **Deploy from a branch**.
5. Select your main branch and `/ (root)`.
6. Save.

The public site will be available through your GitHub Pages URL.

## Contact

Email: shapingfuture22@gmail.com
